#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MethArCT 使用示例脚本

这个脚本展示了如何使用MethArCT进行各种分析：
- 核心功能：Diamond代谢通路分析（必需）
- 可选功能：Tome温度预测、CheckM2基因组质量评估
"""

import os
import sys
from pathlib import Path

# 添加项目路径到Python路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from metharct.core.diamond_analyzer import DiamondAnalyzer
from metharct.core.tome_analyzer import TomeAnalyzer
from metharct.core.checkm2_analyzer import CheckM2Analyzer
from metharct.core.pathway_predictor import PathwayPredictor
from metharct.utils.config import Config
from metharct.utils.logger import setup_logger

def main():
    """
    主函数：演示MethArCT的基本使用方法
    
    注意：
    - Diamond分析是核心功能，必需安装
    - Tome和CheckM2是可选功能，如果未安装会跳过相应分析
    """
    # 设置日志
    logger = setup_logger("example", level="INFO")
    logger.info("开始MethArCT示例分析")
    
    # 加载配置
    config = Config()
    
    # 示例输入文件（请替换为您的实际文件路径）
    input_protein_file = "example_protein.fasta"  # 蛋白质序列文件
    input_genome_file = "example_genome.fasta"    # 基因组序列文件
    output_dir = "example_results"                # 输出目录
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 检查输入文件是否存在
    if not os.path.exists(input_protein_file):
        logger.warning(f"蛋白质文件 {input_protein_file} 不存在，跳过相关分析")
        print("请将您的蛋白质序列文件重命名为 'example_protein.fasta' 或修改脚本中的文件路径")
    
    if not os.path.exists(input_genome_file):
        logger.warning(f"基因组文件 {input_genome_file} 不存在，跳过相关分析")
        print("请将您的基因组序列文件重命名为 'example_genome.fasta' 或修改脚本中的文件路径")
    
    try:
        # 1. Diamond代谢通路分析（核心功能 - 必需）
        if os.path.exists(input_protein_file):
            logger.info("开始Diamond代谢通路分析（核心功能）")
            diamond_analyzer = DiamondAnalyzer(config)
            
            # 检查Diamond工具是否可用
            if diamond_analyzer.check_availability():
                diamond_results = diamond_analyzer.analyze_file(
                    input_file=input_protein_file,
                    output_dir=os.path.join(output_dir, "diamond"),
                    threads=4,  # 使用4个线程
                    evalue=1e-5  # E-value阈值
                )
                logger.info(f"Diamond分析完成，结果保存在: {diamond_results['output_file']}")
                print(f"检测到的代谢通路: {diamond_results['pathways']}")
            else:
                logger.error("Diamond工具不可用，请检查安装（这是必需的核心功能）")
        
        # 2. Tome温度预测分析（可选功能）
        if os.path.exists(input_protein_file):
            logger.info("开始Tome温度预测分析（可选功能）")
            tome_analyzer = TomeAnalyzer(config)
            
            # 检查Tome工具是否可用
            if tome_analyzer.check_availability():
                tome_results = tome_analyzer.predict_file(
                    input_file=input_protein_file,
                    output_dir=os.path.join(output_dir, "tome")
                )
                logger.info(f"Tome分析完成，结果保存在: {tome_results['output_file']}")
                print(f"预测的最适生长温度: {tome_results['predicted_ogt']}°C")
                print(f"温度分类: {tome_results['temperature_class']}")
            else:
                logger.warning("Tome工具不可用，跳过温度预测分析（这是可选功能）")
        
        # 3. CheckM2基因组质量评估（可选功能）
        if os.path.exists(input_genome_file):
            logger.info("开始CheckM2基因组质量评估（可选功能）")
            checkm2_analyzer = CheckM2Analyzer(config)
            
            # 检查CheckM2工具是否可用
            if checkm2_analyzer.check_availability():
                checkm2_results = checkm2_analyzer.analyze_file(
                    input_file=input_genome_file,
                    output_dir=os.path.join(output_dir, "checkm2"),
                    threads=4
                )
                logger.info(f"CheckM2分析完成，结果保存在: {checkm2_results['output_file']}")
                print(f"基因组完整性: {checkm2_results['completeness']:.2f}%")
                print(f"污染度: {checkm2_results['contamination']:.2f}%")
                print(f"质量等级: {checkm2_results['quality_grade']}")
            else:
                logger.warning("CheckM2工具不可用，跳过基因组质量评估（这是可选功能）")
        
        # 4. 综合分析（需要所有工具都可用）
        if os.path.exists(input_protein_file) and os.path.exists(input_genome_file):
            logger.info("开始综合分析（需要所有工具都可用）")
            pathway_predictor = PathwayPredictor(config)
            
            try:
                comprehensive_results = pathway_predictor.comprehensive_analysis(
                    protein_file=input_protein_file,
                    genome_file=input_genome_file,
                    output_dir=os.path.join(output_dir, "comprehensive"),
                    threads=4
                )
                
                logger.info(f"综合分析完成，结果保存在: {comprehensive_results['output_dir']}")
                print("\n=== 综合分析结果摘要 ===")
                print(f"代谢通路: {comprehensive_results.get('pathways', [])}")
                print(f"耐盐性: {comprehensive_results.get('salt_tolerance', 'Unknown')}")
                print(f"最适生长温度: {comprehensive_results.get('optimal_temperature', 'Unknown')}°C")
                print(f"可培养性: {comprehensive_results.get('culturability', 'Unknown')}")
            except Exception as e:
                logger.warning(f"综合分析失败，可能是因为缺少可选工具: {str(e)}")
                print("\n注意：综合分析需要所有工具（Diamond、Tome、CheckM2）都可用")
        
        logger.info("所有分析完成！")
        print(f"\n所有结果已保存在 '{output_dir}' 目录中")
        
    except Exception as e:
        logger.error(f"分析过程中出现错误: {str(e)}")
        print(f"错误: {str(e)}")
        return 1
    
    return 0

def show_help():
    """
    显示帮助信息
    """
    help_text = """
    MethArCT 使用示例脚本
    
    使用方法:
        python example_usage.py
    
    准备工作:
    1. 必需工具：
       - Diamond（核心功能，必须安装）
    2. 可选工具（用于扩展功能）：
       - Tome（温度预测）
       - CheckM2（基因组质量评估）
    3. 准备输入文件：
       - example_protein.fasta: 蛋白质序列文件
       - example_genome.fasta: 基因组序列文件（CheckM2分析需要）
    4. 运行脚本进行分析
    
    输出结果:
    - example_results/diamond/: Diamond分析结果（核心功能）
    - example_results/tome/: Tome分析结果（可选功能）
    - example_results/checkm2/: CheckM2分析结果（可选功能）
    - example_results/comprehensive/: 综合分析结果（需要所有工具）
    
    注意事项:
    - 只有Diamond是必需的，其他工具为可选
    - 如果缺少可选工具，相应的分析会被跳过
    - 请根据您的实际文件路径修改脚本中的输入文件名
    - 确保有足够的磁盘空间存储结果
    - 分析时间取决于输入文件大小和系统性能
    """
    print(help_text)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ["-h", "--help", "help"]:
        show_help()
    else:
        exit_code = main()
        sys.exit(exit_code)