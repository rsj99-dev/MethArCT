#!/bin/bash
# MethArCT Unix/Linux/macOS 安装脚本
# 这个脚本帮助您在Unix系统上安装和配置MethArCT

set -e  # 遇到错误时退出

echo "========================================"
echo "MethArCT Unix/Linux/macOS 安装脚本"
echo "========================================"
echo

# 检查操作系统
OS=$(uname -s)
echo "检测到操作系统: $OS"
echo

# 检查Python是否已安装
echo "检查Python安装..."
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到Python3，请先安装Python 3.8或更高版本"
    case $OS in
        "Linux")
            echo "Ubuntu/Debian: sudo apt-get install python3 python3-pip"
            echo "CentOS/RHEL: sudo yum install python3 python3-pip"
            ;;
        "Darwin")
            echo "macOS: brew install python3"
            echo "或从 https://www.python.org/downloads/ 下载"
            ;;
    esac
    exit 1
fi

# 显示Python版本
echo "Python版本:"
python3 --version
echo

# 检查pip
if ! command -v pip3 &> /dev/null; then
    echo "错误: 未找到pip3"
    exit 1
fi

# 检查conda是否已安装
echo "检查Conda安装..."
if ! command -v conda &> /dev/null; then
    echo "警告: 未找到Conda，建议安装Anaconda或Miniconda"
    echo "下载地址: https://www.anaconda.com/products/distribution"
    echo "继续使用pip安装..."
    USE_CONDA=false
else
    echo "Conda版本:"
    conda --version
    echo
    read -p "是否使用Conda创建环境? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        USE_CONDA=true
    else
        USE_CONDA=false
    fi
fi

if [ "$USE_CONDA" = true ]; then
    echo "========================================"
    echo "使用Conda安装MethArCT"
    echo "========================================"
    echo
    
    # 创建conda环境
    echo "创建conda环境..."
    conda env create -f environment.yml
    
    # 激活环境
    echo "激活metharct环境..."
    source $(conda info --base)/etc/profile.d/conda.sh
    conda activate metharct
    
    # 安装MethArCT
    echo "安装MethArCT..."
    pip install -e .
    
else
    echo "========================================"
    echo "使用pip安装MethArCT"
    echo "========================================"
    echo
    
    # 升级pip
    echo "升级pip..."
    python3 -m pip install --upgrade pip
    
    # 创建虚拟环境（推荐）
    read -p "是否创建Python虚拟环境? (推荐) (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "创建虚拟环境..."
        python3 -m venv metharct_env
        source metharct_env/bin/activate
        echo "虚拟环境已激活"
    fi
    
    # 安装依赖
    echo "安装Python依赖包..."
    pip3 install -r requirements.txt
    
    # 安装MethArCT
    echo "安装MethArCT..."
    pip3 install -e .
fi

echo "========================================"
echo "检查外部工具"
echo "========================================"
echo

# 检查Diamond
echo "检查Diamond..."
if ! command -v diamond &> /dev/null; then
    echo "警告: Diamond未安装或不在PATH中"
    case $OS in
        "Linux")
            echo "Ubuntu/Debian: sudo apt-get install diamond-aligner"
            echo "或从 https://github.com/bbuchfink/diamond 下载"
            ;;
        "Darwin")
            echo "macOS: brew install diamond"
            echo "或从 https://github.com/bbuchfink/diamond 下载"
            ;;
    esac
else
    echo "Diamond已安装"
    diamond version
fi
echo

# 检查Tome（通常需要手动安装）
echo "检查Tome..."
if ! command -v tome &> /dev/null; then
    echo "警告: Tome未安装"
    echo "请从 https://github.com/your-tome-repo 下载并安装"
else
    echo "Tome已安装"
fi
echo

# 检查CheckM2
echo "检查CheckM2..."
if ! command -v checkm2 &> /dev/null; then
    echo "警告: CheckM2未安装"
    echo "安装方法: conda install -c bioconda checkm2"
    echo "或参考: https://github.com/chklovski/CheckM2"
else
    echo "CheckM2已安装"
    checkm2 --version
fi
echo

# 测试安装
echo "========================================"
echo "测试安装"
echo "========================================"
echo

echo "测试MethArCT命令..."
if ! command -v metharct &> /dev/null; then
    echo "错误: MethArCT命令不可用"
    echo "请检查安装是否成功，或尝试直接运行:"
    echo "python3 -m metharct.cli.main --help"
    exit 1
else
    echo "MethArCT命令可用！"
    metharct --help | head -10
fi

echo
echo "========================================"
echo "安装完成！"
echo "========================================"
echo
echo "使用方法:"
echo "  metharct --help                    # 查看帮助"
echo "  metharct comprehensive --help      # 查看综合分析帮助"
echo "  python3 example_usage.py          # 运行示例脚本"
echo
echo "注意事项:"
if [ "$USE_CONDA" = true ]; then
    echo "1. 使用前请激活环境: conda activate metharct"
else
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "1. 使用前请激活虚拟环境: source metharct_env/bin/activate"
    fi
fi
echo "2. 确保Diamond、Tome、CheckM2工具已正确安装"
echo "3. 准备参考数据库文件"
echo
echo "示例命令:"
echo "  metharct comprehensive --input protein.fasta --output results/"
echo

# 创建桌面快捷方式（可选）
read -p "是否创建启动脚本? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    cat > run_metharct.sh << 'EOF'
#!/bin/bash
# MethArCT 启动脚本

# 激活环境（如果使用conda或虚拟环境）
if command -v conda &> /dev/null; then
    source $(conda info --base)/etc/profile.d/conda.sh
    conda activate metharct 2>/dev/null || true
fi

# 如果使用虚拟环境
if [ -f "metharct_env/bin/activate" ]; then
    source metharct_env/bin/activate
fi

# 运行MethArCT
metharct "$@"
EOF
    chmod +x run_metharct.sh
    echo "启动脚本已创建: run_metharct.sh"
    echo "使用方法: ./run_metharct.sh --help"
fi

echo "安装完成！"