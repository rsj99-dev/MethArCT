# MethArCT - 产甲烷古菌培养组学工具包

## MethArCT

## 简介

MethArCT (Methanogenic Archaeal Culturomics Toolkit) 是一个专门用于产甲烷古菌培养组学分析的综合工具包。该工具集成了多种生物信息学分析功能，能够预测微生物的代谢通路、耐盐性、最适生长温度和可培养性。

## 主要功能

### 核心功能（必需）
- **代谢通路预测**: 甲烷、硫、氮代谢途径分析（21种通路）- 基于Diamond工具
- **耐盐性评估**: 基于基因数据库的盐耐受性预测
- **可培养性评估**: 基于代谢通路的培养难度评估

### 扩展功能（可选）
- **温度预测**: 最适生长温度(OGT)预测 - 需要安装Tome工具
- **基因组质量评估**: 基于CheckM2的基因组完整性和污染评估 - 需要安装CheckM2工具

## 系统要求

### 基本要求
- **Python**: 3.8+
- **必需工具**: Diamond
- **操作系统**: Windows, Linux, macOS

### 可选工具
- **Tome**: 用于最适生长温度预测（可选）
- **CheckM2**: 用于基因组质量评估（可选）

## 快速安装指南

### 步骤1: 获取项目
```bash
# 克隆项目到本地
git clone https://github.com/your-username/MethArCT.git
cd MethArCT
```

### 步骤2: 创建Python环境
```bash
# 使用conda创建环境（推荐）
conda env create -f environment.yml
conda activate metharct

# 或使用pip创建虚拟环境
python -m venv metharct_env
# Windows激活:
metharct_env\Scripts\activate
# Linux/macOS激活:
source metharct_env/bin/activate
```

### 步骤3: 安装核心依赖
```bash
# 安装Python依赖包
pip install -r requirements.txt

# 安装项目为可执行命令
pip install -e .

# 安装必需的Diamond工具
conda install -c bioconda diamond
```

### 步骤4: 验证安装
```bash
# 测试核心功能
python quick_test.py

# 检查命令行工具
metharct --help
```

## 可选工具安装（扩展功能）

如果您需要使用温度预测或基因组质量评估功能，可以安装以下可选工具：

### Tome工具安装（温度预测）
```bash
# 在conda环境中安装
conda install -c bioconda tome

# 验证安装
tome --help
```

### CheckM2工具安装（基因组质量评估）
```bash
# 在conda环境中安装
conda install -c bioconda checkm2

# 验证安装
checkm2 --help
```

### Windows用户特别说明

**重要提示**: 对于Windows用户，如果在安装Tome和CheckM2时遇到兼容性问题，建议使用WSL (Windows Subsystem for Linux) 环境：

1. **安装WSL2**:
   - 在PowerShell中运行: `wsl --install`
   - 重启计算机

2. **在WSL中安装工具**:
   ```bash
   # 进入WSL环境
   wsl
   
   # 安装conda（如果未安装）
   wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
   bash Miniconda3-latest-Linux-x86_64.sh
   
   # 创建环境并安装工具
   conda create -n bioinfo python=3.8
   conda activate bioinfo
   conda install -c bioconda diamond tome checkm2
   ```

3. **配置项目使用WSL**:
   - 参考项目中的 `example_wsl_usage.py` 文件
   - 或在配置文件中指定WSL路径

## 详细使用指南

### 1. 基本使用方法

#### 1.1 命令行使用（推荐）

**核心分析（仅使用Diamond）**:
```bash
# 代谢通路分析 - 这是核心功能，无需额外工具
metharct diamond "protein(1).faa" -o results/

# 综合分析（跳过可选工具）
metharct comprehensive "protein(1).faa" -o results/ --skip-tome --skip-checkm2
```

**完整分析（需要安装可选工具）**:
```bash
# 包含所有功能的综合分析
metharct comprehensive "protein(1).faa" -o results/

# 单独运行可选分析
metharct tome "protein(1).faa" -o results/        # 需要Tome
metharct checkm2 "genome.fasta" -o results/      # 需要CheckM2
```

#### 1.2 Python脚本使用
```python
from metharct import MethArCTAnalyzer

# 创建分析器实例
analyzer = MethArCTAnalyzer()

# 仅使用核心功能（Diamond分析）
results = analyzer.analyze_diamond('protein_sequences.faa')

# 完整分析（如果安装了可选工具）
results = analyzer.comprehensive_analysis('protein_sequences.faa')

print(results)
```

### 2. 输入文件要求

#### 2.1 文件格式
- **支持格式**: FASTA格式 (.fa, .fasta, .faa)
- **文件大小**: 建议不超过50MB
- **字符编码**: UTF-8

#### 2.2 序列类型
- **蛋白质序列**: 用于Diamond代谢通路分析和Tome温度预测
- **基因组序列**: 用于CheckM2基因组质量评估

#### 2.3 文件名注意事项
- 如果文件名包含特殊字符（如括号、空格），请用引号包围
- 示例: `"protein(1).faa"` 而不是 `protein(1).faa`

### 3. 测试安装

#### 3.1 快速测试
```bash
# 测试核心功能
python quick_test.py

# 检查命令行工具
metharct --help
```

#### 3.2 使用示例文件测试
```bash
# 使用项目提供的示例文件进行测试
metharct diamond "protein(1).faa" -o test_results/

# 如果安装了可选工具，可以运行完整测试
metharct comprehensive "protein(1).faa" -o test_results/
```

### 4. 输出结果说明

#### 4.1 核心功能输出（Diamond分析）
分析完成后，在指定的输出目录中会生成：

- **代谢通路分析结果**:
  - `[文件名]_diamond_summary.csv` - 代谢通路汇总表
  - `[文件名]_diamond_results.json` - 详细分析结果
  - `[文件名]_*_diamond.tsv` - 各通路的详细比对结果

- **综合分析报告**:
  - `[文件名]_integrated_summary.csv` - 综合评估结果
  - `[文件名]_comprehensive_analysis.json` - 完整分析数据
  - `[文件名]_analysis_summary.txt` - 文本格式摘要

#### 4.2 可选功能输出

**Tome分析结果**（如果安装了Tome）:
- `[文件名]_tome/` - Tome分析输出目录
- 温度预测相关文件

**CheckM2分析结果**（如果安装了CheckM2）:
- `[文件名]_checkm2/` - CheckM2分析输出目录
- `quality_report.tsv` - 基因组质量报告

### 5. 常见问题解决

#### 5.1 安装相关问题

**命令行入口点问题**:
```bash
# 如果metharct命令不可用，但包已安装，可以使用以下方式
python -m metharct.cli.main --help

# 重新安装项目（修复命令行入口点）
pip uninstall metharct -y
pip install -e .

# 检查环境是否正确激活
conda activate metharct
```

**Diamond工具缺失**:
```bash
# 确保在正确的conda环境中
conda activate metharct

# 安装Diamond（核心必需工具）
conda install -c bioconda diamond

# 验证安装
diamond --help
```

#### 5.2 运行时问题

**文件名包含特殊字符**:
```bash
# 错误方式
metharct diamond protein(1).faa -o results/

# 正确方式
metharct diamond "protein(1).faa" -o results/
```

**权限问题（Windows）**:
- 确保在有写入权限的目录中运行
- 避免在系统目录中创建输出文件

#### 5.3 可选工具问题

**Tome或CheckM2安装失败**:
- 这些是可选工具，不影响核心功能
- 可以使用 `--skip-tome` 和 `--skip-checkm2` 参数跳过
- Windows用户建议在WSL环境中安装这些工具

**WSL配置（仅针对可选工具）**:
```bash
# 安装WSL2
wsl --install

# 在WSL中安装conda和工具
wsl
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
bash Miniconda3-latest-Linux-x86_64.sh
conda install -c bioconda tome checkm2
```

## 快速开始指南

### 第一步：验证安装
```bash
# 检查核心工具是否安装成功
metharct --help

# 如果上述命令失败，可以使用以下方式（功能完全相同）
python -m metharct.cli.main --help

# 检查Diamond工具
diamond --help
```

### 第二步：准备数据
- 准备FASTA格式的蛋白质序列文件
- 确保文件名不包含特殊字符，或用引号包围

### 第三步：运行分析
```bash
# 核心功能分析
metharct diamond "your_protein.faa" -o results/

# 如果metharct命令不可用，使用以下方式（功能完全相同）（推荐）
python -m metharct.cli.main diamond "your_protein.faa" -o results/

# 完整分析（如果安装了可选工具）
metharct comprehensive "your_protein.faa" -o results/
# 或者
python -m metharct.cli.main comprehensive "your_protein.faa" -o results/
```

### 第四步：查看结果
- 打开输出目录中的 `*_integrated_summary.csv` 文件
- 查看 `*_analysis_summary.txt` 了解分析摘要

## 学习资源

- 📝 **Python使用示例**: [example_usage.py](example_usage.py)
- 🖥️ **WSL使用示例**: [example_wsl_usage.py](example_wsl_usage.py)
- 🐛 **问题报告**: GitHub Issues

## 新手建议

1. **从核心功能开始**: 先使用Diamond分析，熟悉工具操作
2. **理解输出结果**: 重点关注代谢复杂性和培养潜力评估
3. **逐步扩展**: 在需要时再安装和使用可选工具
4. **遇到问题**: 查看常见问题解决部分，或提交GitHub Issue

## 数据库说明

MethArCT包含以下代谢通路数据库：

### 甲烷代谢通路（8种）
- 甲酸甲烷、乙酸甲烷、甲醇甲烷等多种产甲烷途径

### 硫代谢通路（6种）
- 硫酸盐还原、硫氧化、硫化氢氧化等

### 氮代谢通路（4种）
- 硝化、反硝化、氨氧化等

### 其他通路（3种）
- 耐盐性、可培养性评估相关基因

## 技术支持

### 获取帮助
- 📖 **详细文档**: [TESTING.md](TESTING.md)
- 📝 **使用示例**: [example_usage.py](example_usage.py)
- 🖥️ **WSL配置**: [example_wsl_usage.py](example_wsl_usage.py)
- 🐛 **问题报告**: GitHub Issues

### 常见问题
1. **安装问题**: 查看上方"常见问题解决"部分
2. **使用问题**: 参考"快速开始指南"
3. **结果解读**: 查看"输出结果说明"

## 项目信息

### 许可证
MIT License - 详见 [LICENSE](LICENSE) 文件

### 版本信息
- **当前版本**: 1.0.0
- **Python要求**: 3.8+
- **核心依赖**: Diamond

### 引用
如果您在研究中使用了MethArCT，请引用：
```
[论文信息待发布]
```

### 联系方式
- **GitHub Issues**: 报告问题和功能请求
- **项目主页**: [GitHub Repository]

---

**感谢使用MethArCT！** 🧬

如果您觉得这个工具有用，请给我们一个⭐️！