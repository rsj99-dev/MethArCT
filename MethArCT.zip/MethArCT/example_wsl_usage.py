#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MethArCT WSL使用示例

本示例展示如何配置MethArCT以使用WSL环境中安装的工具：
- 必需工具：Diamond（核心功能）
- 可选工具：CheckM2、Tome（扩展功能）
"""

import os
from metharct.utils.config_wsl import WSLConfig
from metharct.core.metharct_analyzer import MethArCTAnalyzer

def main():
    """
    WSL环境使用示例
    """
    print("=== MethArCT WSL环境使用示例 ===")
    
    # 1. 创建WSL配置
    print("\n1. 创建WSL配置...")
    config = WSLConfig()
    
    # 2. 检查WSL环境
    print("\n2. 检查WSL环境...")
    if not config.check_wsl_available():
        print("错误：WSL环境不可用")
        return
    
    print("WSL环境可用")
    
    # 3. 检查工具可用性
    print("\n3. 检查工具可用性...")
    
    # 检查Diamond（必需工具）
    print("\n核心工具（必需）：")
    if config.check_tool_in_wsl('diamond'):
        print("✓ Diamond在WSL中可用（核心功能）")
    else:
        print("✗ Diamond在WSL中不可用（这是必需的核心功能！）")
        print("  安装命令：wsl conda install -c bioconda diamond")
    
    # 检查可选工具
    print("\n可选工具（扩展功能）：")
    # 检查CheckM2
    if config.check_tool_in_wsl('checkm2'):
        print("✓ CheckM2在WSL中可用（基因组质量评估）")
    else:
        print("✗ CheckM2在WSL中不可用（可选功能）")
        print("  安装命令：wsl conda install -c bioconda checkm2")
    
    # 检查Tome
    if config.check_tool_in_wsl('tome'):
        print("✓ Tome在WSL中可用（温度预测）")
    else:
        print("✗ Tome在WSL中不可用（可选功能）")
        print("  安装命令：wsl conda install -c bioconda tome")
    
    # 4. 配置WSL使用
    print("\n4. 配置WSL使用...")
    
    # 启用WSL模式
    config.enable_wsl_mode()
    
    # 设置WSL路径（如果需要自定义）
    # config.set_wsl_paths({
    #     'diamond': '/home/username/miniconda3/bin/diamond',
    #     'checkm2': '/home/username/miniconda3/bin/checkm2',
    #     'tome': '/home/username/miniconda3/bin/tome'
    # })
    
    print("WSL模式已启用")
    
    # 5. 创建分析器实例
    print("\n5. 创建分析器实例...")
    try:
        analyzer = MethArCTAnalyzer(config=config)
        print("✓ MethArCT分析器创建成功（WSL模式）")
        
        # 6. 运行示例分析（如果有测试数据）
        test_fasta = "test_data/test_sequences.fasta"
        if os.path.exists(test_fasta):
            print(f"\n6. 运行测试分析: {test_fasta}")
            results = analyzer.analyze_sequences(test_fasta)
            print(f"分析完成，结果保存在: {results['output_dir']}")
        else:
            print(f"\n6. 测试数据文件不存在: {test_fasta}")
            print("请准备FASTA格式的序列文件进行测试")
            
    except Exception as e:
        print(f"✗ 创建分析器失败: {e}")
        print("请检查WSL环境和工具安装")
    
    print("\n=== WSL使用示例完成 ===")

def show_wsl_installation_guide():
    """
    显示WSL安装指南
    """
    print("=== WSL环境安装指南 ===")
    print()
    print("1. 安装WSL:")
    print("   wsl --install")
    print()
    print("2. 在WSL中安装Miniconda:")
    print("   wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh")
    print("   bash Miniconda3-latest-Linux-x86_64.sh")
    print()
    print("3. 在WSL中安装生物信息学工具:")
    print("   # 必需工具（核心功能）")
    print("   conda install -c bioconda diamond")
    print()
    print("   # 可选工具（扩展功能）")
    print("   conda install -c bioconda checkm2 tome")
    print()
    print("4. 验证安装:")
    print("   # 验证核心工具")
    print("   wsl diamond version")
    print()
    print("   # 验证可选工具")
    print("   wsl checkm2 --version")
    print("   wsl tome --version")
    print()
    print("5. 运行MethArCT WSL示例:")
    print("   python example_wsl_usage.py")
    print()
    print("注意：只有Diamond是必需的，CheckM2和Tome为可选工具")
    print()

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--install-guide":
        show_wsl_installation_guide()
    else:
        main()