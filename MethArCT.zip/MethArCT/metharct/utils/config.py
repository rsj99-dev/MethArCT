#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration management for MethArCT

Handles configuration loading, database paths, and tool settings.
"""

import os
import yaml
import json
from pathlib import Path
from typing import Dict, Any, Optional

class Config:
    """Configuration manager for MethArCT"""
    
    def __init__(self, config_file: Optional[str] = None):
        self.config_file = config_file
        self.config = self._load_default_config()
        
        if config_file and os.path.exists(config_file):
            self._load_config_file(config_file)
    
    def _load_default_config(self) -> Dict[str, Any]:
        """Load default configuration"""
        return {
            'tools': {
                'diamond': {
                    'path': 'diamond',
                    'wsl_path': 'wsl diamond',
                    'use_wsl': False,
                    'threads': 4,
                    'evalue': 1e-5,
                    'max_target_seqs': 1,
                    'identity_threshold': 30.0
                },
                'tome': {
                    'path': 'tome',
                    'wsl_path': 'wsl tome',
                    'use_wsl': False,
                    'threads': 4
                },
                'checkm2': {
                    'path': 'checkm2',
                    'wsl_path': 'wsl checkm2',
                    'use_wsl': False,
                    'threads': 4
                }
            },
            'databases': {
                'base_dir': 'data/databases',
                'methane_pathways': {
                    'CO2-CH4': 'methane/processed_CO2-CH4.fasta',
                    'JIAAN-CH4': 'methane/processed_JIAAN-CH4.fasta',
                    'JIACHUN-CH4': 'methane/processed_JIACHUN-CH4.fasta',
                    'JIALIUCHUN-CH4': 'methane/processed_JIALIUCHUN-CH4.fasta',
                    'YISUAN-CH4': 'methane/processed_YISUAN-CH4.fasta',
                    'C16-CH4': 'methane/processed_C16-CH4.fasta',
                    'CO-CH4': 'methane/processed_CO-CH4.fasta',
                    'JIASUAN-CH4': 'methane/processed_JIASUAN-CH4.fasta',
                    'JIAYANGJI-CH4': 'methane/processed_JIAYANGJI-CH4.fasta',
                    'ZHIFANGSUAN-CH4': 'methane/processed_ZHIFANGSUAN-CH4.fasta',
                    '2JIAAN-CH4': 'methane/processed_2JIAAN-CH4.fasta',
                    '3JIAAN-CH4': 'methane/processed_3JIAAN-CH4.fasta'
                },
                'sulfur_pathways': {
                    'ASR': 'sulfur/Assimilatory sulfate reduction.fasta',
                    'SO': 'sulfur/Sulfide oxidation.fasta',
                    'SOX': 'sulfur/Sulfur oxidation, SOX system.fasta',
                    'S4I': 'sulfur/Sulfur oxidation, tetrathionate intermediate (S4I) pathway.fasta',
                    'SR': 'sulfur/Sulfur reduction.fasta',
                    'DSR': 'sulfur/Dissimilatory sulfate reduction.fasta'
                },
                'nitrogen_pathways': {
                    'ANR': 'nitrogen/Assimilatory nitrate reduction.fasta',
                    'DEN': 'nitrogen/Denitrification.fasta',
                    'DNR': 'nitrogen/Dissimilatory nitrate reduction.fasta',
                    'NIT': 'nitrogen/Nitrification.fasta'
                },
                'salt_tolerance': 'salt/naiyan_data.fasta',
                'cultivation': 'cultivation/newprotein.fasta'
            },
            'pathway_names': {
                # Methane pathways
                'CO2-CH4': 'CO2还原产甲烷途径',
                'JIAAN-CH4': '甲胺产甲烷途径',
                'JIACHUN-CH4': '甲醇产甲烷途径',
                'JIALIUCHUN-CH4': '甲硫醇产甲烷途径',
                'YISUAN-CH4': '乙酸产甲烷途径',
                'C16-CH4': '碳16产甲烷途径',
                'CO-CH4': '一氧化碳产甲烷途径',
                'JIASUAN-CH4': '甲酸产甲烷途径',
                'JIAYANGJI-CH4': '甲氧基产甲烷途径',
                'ZHIFANGSUAN-CH4': '脂肪酸产甲烷途径',
                '2JIAAN-CH4': '二甲胺产甲烷途径',
                '3JIAAN-CH4': '三甲胺产甲烷途径',
                # Sulfur pathways
                'ASR': '同化型硫酸盐还原途径',
                'SO': '硫化物氧化途径',
                'SOX': '硫氧化SOX系统途径',
                'S4I': '硫氧化四硫酸盐中间体途径',
                'SR': '硫还原途径',
                'DSR': '异化型硫酸盐还原途径',
                # Nitrogen pathways
                'ANR': '同化型硝酸盐还原途径',
                'DEN': '反硝化途径',
                'DNR': '异化型硝酸盐还原途径',
                'NIT': '硝化途径',
                # Others
                'NAIYAN': '耐盐特性',
                'CULTIVATION': '栽培评估'
            },
            'reference_sequence_counts': {
                # Methane pathways
                'CO2-CH4': 12,
                'JIAAN-CH4': 10,
                'JIACHUN-CH4': 7,
                'JIALIUCHUN-CH4': 6,
                'YISUAN-CH4': 14,
                'C16-CH4': 15,
                'CO-CH4': 11,
                'JIASUAN-CH4': 15,
                'JIAYANGJI-CH4': 9,
                'ZHIFANGSUAN-CH4': 12,
                '2JIAAN-CH4': 10,
                '3JIAAN-CH4': 10,
                # Sulfur pathways
                'ASR': 9,
                'SO': 2,
                'SOX': 7,
                'S4I': 5,
                'SR': 3,
                'DSR': 8,
                # Nitrogen pathways
                'ANR': 9,
                'DEN': 10,
                'DNR': 9,
                'NIT': 4,
                # Others
                'NAIYAN': 15,
                'CULTIVATION': 14192
            },
            'output': {
                'base_dir': 'results',
                'formats': ['csv', 'json', 'html']
            },
            'logging': {
                'level': 'INFO',
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                'file': 'metharct.log'
            }
        }
    
    def _load_config_file(self, config_file: str):
        """Load configuration from file"""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                    user_config = yaml.safe_load(f)
                elif config_file.endswith('.json'):
                    user_config = json.load(f)
                else:
                    raise ValueError(f"Unsupported config file format: {config_file}")
            
            # Merge user config with default config
            self._merge_config(self.config, user_config)
        except Exception as e:
            print(f"Warning: Failed to load config file {config_file}: {e}")
    
    def _merge_config(self, default: Dict, user: Dict):
        """Recursively merge user config into default config"""
        for key, value in user.items():
            if key in default and isinstance(default[key], dict) and isinstance(value, dict):
                self._merge_config(default[key], value)
            else:
                default[key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value using dot notation"""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value using dot notation"""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
    
    def get_database_path(self, db_type: str, db_name: str) -> str:
        """Get full path to database file"""
        base_dir = self.get('databases.base_dir', 'data/databases')
        
        if db_type == 'methane':
            rel_path = self.get(f'databases.methane_pathways.{db_name}')
        elif db_type == 'sulfur':
            rel_path = self.get(f'databases.sulfur_pathways.{db_name}')
        elif db_type == 'nitrogen':
            rel_path = self.get(f'databases.nitrogen_pathways.{db_name}')
        elif db_type == 'salt':
            rel_path = self.get('databases.salt_tolerance')
        elif db_type == 'cultivation':
            rel_path = self.get('databases.cultivation')
        else:
            raise ValueError(f"Unknown database type: {db_type}")
        
        if not rel_path:
            raise ValueError(f"Database {db_name} not found in {db_type} databases")
        
        return os.path.join(base_dir, rel_path)
    
    def get_all_database_paths(self) -> Dict[str, str]:
        """Get all database paths"""
        paths = {}
        base_dir = self.get('databases.base_dir', 'data/databases')
        
        # Methane pathways
        for name, path in self.get('databases.methane_pathways', {}).items():
            paths[name] = os.path.join(base_dir, path)
        
        # Sulfur pathways
        for name, path in self.get('databases.sulfur_pathways', {}).items():
            paths[name] = os.path.join(base_dir, path)
        
        # Nitrogen pathways
        for name, path in self.get('databases.nitrogen_pathways', {}).items():
            paths[name] = os.path.join(base_dir, path)
        
        # Salt tolerance
        salt_path = self.get('databases.salt_tolerance')
        if salt_path:
            paths['NAIYAN'] = os.path.join(base_dir, salt_path)
        
        # Cultivation
        cult_path = self.get('databases.cultivation')
        if cult_path:
            paths['CULTIVATION'] = os.path.join(base_dir, cult_path)
        
        return paths
    
    def save_config(self, output_file: str):
        """Save current configuration to file"""
        with open(output_file, 'w', encoding='utf-8') as f:
            if output_file.endswith('.yaml') or output_file.endswith('.yml'):
                yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)
            elif output_file.endswith('.json'):
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            else:
                raise ValueError(f"Unsupported output format: {output_file}")